from flask import Flask, request, jsonify
from PIL import Image
from sentence_transformers import SentenceTransformer, util
from flask_cors import CORS
import io
import numpy as np

app = Flask(__name__)
CORS(app)  # Enable CORS for your Flask app

# Load the OpenAI CLIP Model once at startup
print('Loading CLIP Model...')
model = SentenceTransformer('clip-ViT-B-32')

@app.route('/verify-image', methods=['POST'])
def verify_image():
    if 'image' not in request.files:
        return jsonify({'error': 'No image uploaded'}), 400

    file = request.files['image']
    try:
        # Load and preprocess the uploaded image
        img = Image.open(file.stream).convert('RGB')
        
        # Load the reference image (for comparison)
        source_image = Image.open('bottle.jpg').convert('RGB')

        # Encode both images as strings (or another method if you are dealing with images)
        encoded_image = model.encode([img], convert_to_tensor=True)
        encoded_source_image = model.encode([source_image], convert_to_tensor=True)

        # Compute cosine similarity
        similarity = util.pytorch_cos_sim(encoded_image, encoded_source_image)

        # Set a threshold for similarity (you can adjust this based on your needs)
        threshold = 0.7  # Example threshold; adjust as needed
        if similarity.item() >= threshold:
            return jsonify({'message': 'Image is valid', 'similarity': similarity.item()}), 200
        else:
            return jsonify({'message': 'Image is not valid', 'similarity': similarity.item()}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
